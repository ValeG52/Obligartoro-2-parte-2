﻿using Dominio;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Filters;

namespace WebApplication1.Controllers
{
    [LoginFilter]
    public class TipoDeGastoController : Controller
    {
        Sistema s = Sistema.GetInstancia();

        public IActionResult CargarNuevoTG()
        {

            
            return View();
        }

        [HttpPost]
        public IActionResult CargarNuevoTG(TipoDeGastos tgNuevo)
        {

            s.AltaTipoGastos(tgNuevo);
            return View();
        }
        public IActionResult EliminarTG()
        {
            List<TipoDeGastos> tg = s.GetTG();

            return View(tg);
        }

        public IActionResult Delete()
        {
          

            return View();
        }

        [HttpPost]
        public IActionResult Delete(int id, IFormCollection form)
        {
            try
            {
                TipoDeGastos aEliminar = s.GetTgById(id);
                s.EliminarTg(id);
                return RedirectToAction("EliminarTG");
            }
            catch (Exception e)
            {
                ViewBag.msg = e.Message;
                TipoDeGastos aEliminar = s.GetTgById(id);
                return View(aEliminar);
            }

        }
    }
}
