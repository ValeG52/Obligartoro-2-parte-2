﻿using Dominio;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Filters;
namespace WebApplication1.Controllers
{
    [LoginFilter]
    public class PagoController : Controller
    {
        Sistema s = Sistema.GetInstancia();
        public IActionResult ListarPagosDelMes()
        {
           
            List<Pago> pagos = s.GetTodosLosPagos(HttpContext.Session.GetInt32("LogueadoId"));
            pagos.Sort();
            return View(pagos);

        }

        public IActionResult CargarPagos()
        {

            return View();
        }

        //GET RECURRENTE
        public IActionResult CargarRecurrente()
        {
            List<TipoDeGastos> tg = s.GetTG();
            ViewBag.TipoDeGasto = tg;
           

            return View();                    
        }

        //POST RECURRENTE 
        [HttpPost]
        public IActionResult CargarRecurrente(Recurrente nuevo, int IdTipoDeGasto, int cuotas)
        {

            nuevo.Usuario = s.GetUsuarioById(HttpContext.Session.GetInt32("LogueadoId"));
            nuevo.FechaIngresoPago = DateTime.Now;
            TipoDeGastos b = s.GetTgById(IdTipoDeGasto);
            nuevo.TipoDeGasto = b;
            if(cuotas == 0)
            {
                nuevo.FechaHasta = null;
            }
            else
            {
                nuevo.FechaHasta = s.SumarMeses(nuevo.FechaIngresoPago, cuotas);

            }
            try
            {
                s.AltaPago(nuevo);
                ViewBag.Mensaje = "Pago creado correctamente.";
            }
            catch (Exception e)
            {
                ViewBag.Error = "Los campos tienen que estar completos";
            }
            

            List<TipoDeGastos> tg = s.GetTG();
            ViewBag.TipoDeGasto = tg;
            return View();
        }


        //GET UNICO
        public IActionResult CargarUnico()
        { 
            List<TipoDeGastos> tg = s.GetTG();
            ViewBag.TipoDeGasto = tg;
          

            return View();

        }

        [HttpPost]
        //POST UNICO
        public IActionResult CargarUnico(Unico nuevo, int IdTipoDeGasto)
        {
            nuevo.Usuario = s.GetUsuarioById(HttpContext.Session.GetInt32("LogueadoId"));
            nuevo.FechaIngresoPago = DateTime.Now;
            TipoDeGastos b = s.GetTgById(IdTipoDeGasto);
            
            nuevo.TipoDeGasto = b;


            try
            {
                s.AltaPago(nuevo);
                ViewBag.Mensaje = "Pago creado correctamente.";
            }
            catch (Exception e)
            {
                ViewBag.Error = "Los campos tienen que estar completos";
            }

           
            ViewBag.TipoDeGasto = s.GetTG();

   
            return View(nuevo);





        }


        [GerenteFilter]
        public IActionResult VerPagosEquipo()
        {
            
            List<Pago> pagosEquipo = s.GetPagosPorEquipo(HttpContext.Session.GetInt32("LogueadoId"), DateTime.Now);
            pagosEquipo.Sort();


            return View(pagosEquipo);
        }
        [GerenteFilter]
        [HttpPost]
        public IActionResult VerPagosEquipoPorFecha(DateTime fecha)
        {
            
            //DateTime fechaConvertida = DateTime.Parse(fecha + "-01");// convertirlo a DateTime
            Usuario usu= s.GetUsuarioById(HttpContext.Session.GetInt32("LogueadoId"));

            // filtrar por fechaConvertida.Month y fechaConvertida.Year
            List<Pago> pagosDeLaFecha = s.BuscarPagosByFecha(fecha);
            List<Pago> pagosEquipoPorFecha = s.GetPagosByLista(usu, pagosDeLaFecha);
            pagosEquipoPorFecha.Sort();


            return View("VerPagosEquipo", pagosEquipoPorFecha);
        }

        [GerenteFilter]
        public IActionResult VerCargaDePagos()

        {
            DateTime hoy = DateTime.Now;
            List<Pago> cargaDePagos = s.BuscarPagosByFecha(hoy);
            

            return View(cargaDePagos);
        }

    }
}
