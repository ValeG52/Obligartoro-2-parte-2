﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Equipo
    {
        private static int _ultimoId = 1;
        public int Id { get; set; }
        public string Nombre { get; set; }


        public override string ToString()
        {
            return $"{Nombre}";
        }


        public Equipo(string nom)
        {
           Id = _ultimoId++;
           Nombre = nom;
        }
        

         

        public void Validar()
        {
            if (String.IsNullOrEmpty(Nombre))
            {
                throw new Exception("El nombre del equipo no puede estar vacio");

            }
            if (Nombre.Length < 3)
            {
                throw new Exception("El nombre del equipo debe tener al menos 3 caracteres");

            }

        }

    }
}
