﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Unico:Pago 
    {
        public int Recibo { get; set; }


        public Unico(Usuario usu, string descripcion, TipoDeGastos tg, double monto, int recibo, DateTime fechaIngresoPago) :base(usu, descripcion, monto, tg, fechaIngresoPago)
        {
          
          
            Recibo = recibo;
            
        }

        public Unico():base()
        {
            
        }


    }
}
