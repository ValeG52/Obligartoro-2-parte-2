﻿using Dominio;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Filters;
namespace WebApplication1.Controllers
{
    [LoginFilter]
    public class PagoController : Controller
    {
        Sistema s = Sistema.GetInstancia();
        public IActionResult ListarPagosDelMes()
        {
           
            List<Pago> pagos = s.GetTodosLosPagos(HttpContext.Session.GetInt32("LogueadoId"));

            return View(pagos);

        }

        public IActionResult CargarPagos()
        {

            return View();
        }

        //GET RECURRENTE
        public IActionResult CargarRecurrente()
        {
            List<TipoDeGastos> tg = s.GetTG();
            ViewBag.TipoDeGasto = tg;
           

            return View();                    
        }

        //POST RECURRENTE 
        [HttpPost]
        public IActionResult CargarRecurrente(Recurrente nuevo, int IdTipoDeGasto, int cuotas)
        {

            nuevo.Usuario = s.GetUsuarioById(HttpContext.Session.GetInt32("LogueadoId"));
            nuevo.FechaIngresoPago = DateTime.Now;
            TipoDeGastos b = s.GetTgById(IdTipoDeGasto);
            nuevo.TipoDeGasto = b;
            nuevo.FechaHasta = s.SumarMeses(nuevo.FechaIngresoPago, cuotas);
            s.AltaPago(nuevo);
            List<TipoDeGastos> tg = s.GetTG();
            ViewBag.TipoDeGasto = tg;
            return View();
        }


        //GET UNICO
        public IActionResult CargarUnico()
        { 
            List<TipoDeGastos> tg = s.GetTG();
            ViewBag.TipoDeGasto = tg;
          

            return View();

        }

        [HttpPost]
        //POST UNICO
        public IActionResult CargarUnico(Unico nuevo, int IdTipoDeGasto)
        {
            nuevo.Usuario = s.GetUsuarioById(HttpContext.Session.GetInt32("LogueadoId"));
            nuevo.FechaIngresoPago = DateTime.Now;
            TipoDeGastos b = s.GetTgById(IdTipoDeGasto);
            nuevo.TipoDeGasto = b;


            s.AltaPago(nuevo);

            List<TipoDeGastos> tg = s.GetTG();
            ViewBag.TipoDeGasto = tg;
           

            return View();

        }
        


        public IActionResult VerPagosEquipo()
        {
            
            List<Pago> pagosEquipo = s.GetPagosPorEquipo(HttpContext.Session.GetInt32("LogueadoId"));
            
            return View(pagosEquipo);
        }



        public IActionResult VerCargaDePagos()

        {
            DateTime hoy = DateTime.Now;
            List<Pago> cargaDePagos = s.GetPagosDelMes(hoy);

            return View(cargaDePagos);
        }

    }
}
