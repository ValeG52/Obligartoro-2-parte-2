﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    public class TipoDeGastoController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
