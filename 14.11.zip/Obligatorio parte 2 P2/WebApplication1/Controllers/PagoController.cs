﻿using Dominio;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Filters;
namespace WebApplication1.Controllers
{
    [LoginFilter]
    public class PagoController : Controller
    {
        Sistema s = Sistema.GetInstancia();
        public IActionResult ListarPagosDelMes()
        {
           
            List<Pago> pagos = s.GetPagosDelMes(HttpContext.Session.GetInt32("LogueadoId"));
            return View(pagos);

        }
        public IActionResult CargarPagos()
        {

            return View();
        }

        [HttpPost]
        public IActionResult CargarRecurrente(Pago nuevo)
        {
            List<TipoDeGastos> tg = s.GetTG();
            ViewBag.TipoDeGasto = tg;


            //nuevo.Usuario = s.GetUsuarioById(HttpContext.Session.GetInt32("LogueadoId");
            //nuevo.TipoDeGasto = s.GetTG();
            return View(nuevo);




        }
        public IActionResult CargarUnico(Recurrente nuevo)
        { 
            List<TipoDeGastos> tg = s.GetTG();
            ViewBag.TipoDeGasto = tg;
            return View();

        }

        public IActionResult VerPagosEquipo()
        {
            List<Pago> pagosEquipo = s.GetPagosPorEquipo(HttpContext.Session.GetInt32("LogueadoId"));
            return View(pagosEquipo);
        }

        public IActionResult CargarNuevoTG()
        {
            return View();
        }

        public IActionResult EliminarTG()
        {
            return View();
        }

        public IActionResult VerCargaDePagos()
        {
            return View();
        }

    }
}
