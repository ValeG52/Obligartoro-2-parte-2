﻿using Dominio;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Filters;
namespace WebApplication1.Controllers
{
    [LoginFilter]
    public class UsuarioController : Controller
    {
        Sistema s= Sistema.GetInstancia();
        
        public IActionResult VerPerfil()
        {

            Usuario usuario = s.GetUsuarioById(HttpContext.Session.GetInt32("LogueadoId"));
            double monto = s.CalcularGastosDelMesById(HttpContext.Session.GetInt32("LogueadoId"));
            ViewBag.GastosMes = monto;
            return View(usuario);
        }
    }
}
