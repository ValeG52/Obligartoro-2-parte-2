﻿using Dominio;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Filters;
namespace WebApplication1.Controllers
{
    [LoginFilter]
    public class PagoController : Controller
    {
        Sistema s = Sistema.GetInstancia();
        public IActionResult ListarPagosDelMes()
        {
           
            List<Pago> pagos = s.GetPagosDelMes(HttpContext.Session.GetInt32("LogueadoId"));

            return View(pagos);

        }

        public IActionResult CargarPagos()
        {

            return View();
        }

        //GET RECURRENTE
        public IActionResult CargarRecurrente()
        {
            List<TipoDeGastos> tg = s.GetTG();
            ViewBag.TipoDeGasto = tg;
           

            return View();                    
        }

        //POST RECURRENTE 
        [HttpPost]
        public IActionResult CargarRecurrente(Pago nuevo)
        {

            nuevo.Usuario = s.GetUsuarioById(HttpContext.Session.GetInt32("LogueadoId"));
            nuevo.Fecha = DateTime.Now;
            s.AltaPago(nuevo);
            return View();
        }


        //GET UNICO
        public IActionResult CargarUnico()
        { 
            List<TipoDeGastos> tg = s.GetTG();
            ViewBag.TipoDeGasto = tg;
          

            return View();

        }

        [HttpPost]
        //POST UNICO
        public IActionResult CargarUnico(Pago nuevo)
        {
            nuevo.Usuario = s.GetUsuarioById(HttpContext.Session.GetInt32("LogueadoId"));
            nuevo.Fecha = DateTime.Now;
            s.AltaPago(nuevo);

            List<TipoDeGastos> tg = s.GetTG();
            ViewBag.TipoDeGasto = tg;
           

            return View();

        }
        


        public IActionResult VerPagosEquipo()
        {
            List<Pago> pagosEquipo = s.GetPagosPorEquipo(HttpContext.Session.GetInt32("LogueadoId"));
            return View(pagosEquipo);
        }

        

        public IActionResult VerCargaDePagos()

        {
            DateTime hoy = DateTime.Now;
            List<Pago> cargaDePagos = s.GetCargaDePagos(hoy);

            return View(cargaDePagos);
        }

    }
}
